§align:center
##### §nDislocation§n

§stack[draconicevolution:dislocator]{size:32} §stack[draconicevolution:dislocator_advanced]{size:32} §stack[draconicevolution:dislocator_bound,1,1]{size:32} §stack[draconicevolution:magnet]{size:32} §stack[draconicevolution:magnet,1,1]{size:32}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Draconic Evolution has a number of items designed to assist with your teleportation needs!
§rule{colour:0x606060,height:3,width:100%}