§align:center
##### §nDraconic Belt of Overloading§n

§stack[draconicadditions:overload_belt]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Are mobs just not doing enough damage to dent your shields in the slightest, but are tanky as all get out?  Introducing the Draconic Belt of Overloading!  This useful little belt, once activated (default is Shift+F), will directly reinfuse the power directed into your shields into your muscles, temporarily increasing them by an insane factor!

The amount of increase depends on the current amount of shielding, down to a minimum.  If you run out of shields, it will automatically turn off and let them recharge.  This means that it is best to use this item in bursts rather than continuously.  If used correctly, you can literally kill mobs with your bare hands in one punch!

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicadditions:overload_belt]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}