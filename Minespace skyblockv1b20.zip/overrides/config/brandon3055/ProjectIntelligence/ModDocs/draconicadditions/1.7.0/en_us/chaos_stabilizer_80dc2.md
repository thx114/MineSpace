§align:center
##### §nChaos Stabilizer§n

§stack[draconicadditions:chaos_stabilizer_core]{size:64}
§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Tired of your new armor and tools being out of control?  Enter the Chaos Stabilizer!  Wait, stabilizing chaos?  Is that even possible?!  Yes, it is.  Do not ask how, just know that it is.  This multiblock stucture will help you stabilize the chaos that's running rampant throughout your chaotic gear, causing interference with it's built-in abilities.  It's expensive to craft, but suprisingly effecient once set up.

§img[http://foxmcloud.net/experiments/ChaosStabilizerMultiblock.png]{width:256}

##### §4§nWarning!

Do NOT stand too close to the structure while it's active!  The hunger for items that contain Chaos may also pull you in, and if you don't have flight, there's no way out!  Thankfully, if you haven't started the ritual, you can just break the stabilizer with no repercussions.  HOWEVER, if the ritual is ongoing, the Chaos emitted from said ritual WILL suck in and destroy anything and everything nearby that isn't nailed down.  Only Draconic Shielding (and quite a bit of it too), fancy flying, or teleportation will save you from this if you get caught in it!

§align:center
§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicadditions:chaos_stabilizer_core]
§rule{colour:0x606060,height:3,width:100%,top_pad:3}