§align:center
##### §nDislocator Pedestal§n

§stack[draconicevolution:dislocator_pedestal]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
You have figured out how to create a simple pedestal on which you can place your Basic or Advanced Charms of Dislocation.

Simply right-click with a Charm in your hand to place it on the pedestal, then right-click the pedestal to teleport.

The advantage of this is that the Charms won't take damage or use fuel. The disadvantage is you cannot bring them with you to your destination.

To remove the charm from the pedestal simply shift + right-click with an empty hand.

When it is holding a Basic Charm of Dislocation that has been renamed in an anvil or an Advanced Charm of Dislocation with a destination set either the name or destination will be displayed above the pedestal respectively.

If you hold shift all names will be hidden except the one you are looking at. (Shift behavior can be reversed in the config)

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:dislocator_pedestal]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}