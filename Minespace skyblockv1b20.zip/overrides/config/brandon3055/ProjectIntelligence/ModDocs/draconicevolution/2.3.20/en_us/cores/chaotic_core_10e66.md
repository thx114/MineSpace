§align:center
##### §nChaotic Core§n

§stack[draconicevolution:chaotic_core]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
So your ready for something a little more challenging? You may want to consider chaotic! You will need to fight a §link[draconicevolution:chaos_guardian]{alt_text:"Chaos Guardian"} to get there but the pay out may be worth it!

At this point there isnt a lot you can do at the chaotic teir but if you like insage power gen you may want to check out the §link[draconicevolution:draconic_reactor]{alt_text:"Draconic Reactor"}!

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:chaotic_core]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}