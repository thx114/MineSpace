﻿§align:center
##### §nChaotic Chestplate§n

§stack[draconicadditions:chaotic_chest]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§bStats

Flight
Removes mining slowdown while in the air
Immune to fire damage
+400 Base Shield Capacity
+6 Armor Toughness
+16 Armor

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicadditions:chaotic_chest]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}