§align:center
##### §nInfused Potato Chestplate

§stack[draconicadditions:infused_potato_chest]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§bStats

+2 Armor

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicadditions:infused_potato_chest]{spacing:4}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}