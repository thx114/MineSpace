§align:center
##### §nDraconic Shield Necklace§n

§stack[draconicadditions:draconic_shield_necklace]{size:64}

The Draconic Shield Necklace provides you with 16 shield points, just as much as the §link[draconicadditions:potato_armor]{alt_text:"Potato Armor"} gives!

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicadditions:draconic_shield_necklace]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}