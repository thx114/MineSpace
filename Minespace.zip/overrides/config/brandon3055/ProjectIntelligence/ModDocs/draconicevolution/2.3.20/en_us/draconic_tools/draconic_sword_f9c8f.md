§align:center
##### §nDraconic Sword§n

§img[http://ss.brandon3055.com/a6278]{width:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§b§nStats

§616 Million RF capacity upgradable to 256 Million.

§63x3 base attack radius. Upgradable to 13x13
Note the AOE attack only works when the sword is fully charged (meaning the recharge time after you swing the sword has expired).
(Referring to the new vanilla charging mechanic)

§635 base Attack. Upgradable to 61.25

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconic_sword]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}