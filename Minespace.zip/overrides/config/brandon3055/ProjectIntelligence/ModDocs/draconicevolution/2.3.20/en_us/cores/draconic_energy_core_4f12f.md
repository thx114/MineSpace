§align:center
##### §nDraconic Energy Core§n

§stack[draconicevolution:draconic_energy_core]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
This is a more powerful version of the §link[draconicevolution:cores/wyvern_energy_core]{alt_text:"Wyvern Energy Core"} used in higher tier crafting recipes.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconic_energy_core]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}