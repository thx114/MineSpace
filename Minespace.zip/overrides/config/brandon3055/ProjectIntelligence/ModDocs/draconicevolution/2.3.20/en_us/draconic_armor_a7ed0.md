§align:center
##### §nDraconic Armor§n

Draconic Armor is the ultimate armor!
This armor has all the same abilities as the wyvern armor but upgraded as well as a few new abilities!

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§img[https://raw.githubusercontent.com/brandon3055/Project-Intelligence-Docs/master/Assets/Draconic%20Evolution/Armor/Draconic%20Armor.jpg]{width:30%} 
§rule{colour:0x606060,height:3,width:100%}